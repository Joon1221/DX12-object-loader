INFORMATION
===========
TITLE	:	Bob, MD5 character source file
AUTHOR	:	Ken Beyer (kat)
@	:	info@katsbits.com
URL	:	http://www.katsbits.com


MODEL NAME/s
============
Zip file contains *.blend source file and TGA texture assets for MD5 format testing. Files and media are provided "as is" without any explicit or implied warranty of fuctionality.

- boblampclean.md5mesh & *.md5anim are version "10" MD5 files
- lamp.md5mesh & *.md5anim are older version "6" MD5 files


COPYRIGHT & DISTRIBUTION
========================
Copyright � 2010 KatsBits.
For NON-COMMERCIAL use only.
For COMMERCIAL use get in touch to discuss your requirements, including but not limited to distribution on sites and media with advertising.